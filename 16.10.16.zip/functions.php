<?php 

if (isset($_POST["submit"])) {
	if ($_POST["year_select"]=="4th" && $_POST["year_group"]=="b") {
		form();
	}
}


 ?>




<?php 
	function form(){
		if (isset($_POST["submit"])) {
			$math_401=$_POST["math_401"];
			$math_402=$_POST["math_402"];
			$math_403=$_POST["math_403"];
			$math_404=$_POST["math_404"];
			$math_411=$_POST["math_411"];
			$math_412=$_POST["math_412"];
			$math_413=$_POST["math_413"];
			$math_414=$_POST["math_414"];
			$math_415=$_POST["math_415"];
			$math_416=$_POST["math_416"];
			$math_417=$_POST["math_417"];
			$math_418=$_POST["math_418"];

			$cgpa=(mark_for_100($math_401)*4+mark_for_100($math_403)*4+mark_for_100($math_411)*4+mark_for_100($math_412)*4+mark_for_100($math_413)*4+mark_for_100($math_414)*4+mark_for_100($math_415)*4+mark_for_100($math_418)*4+mark_for_75($math_402)*3+mark_for_75($math_402)*3+mark_for_50($math_416)*2+mark_for_75($math_417)*2)/42;
			 echo "You have got CGPA: ". round($cgpa,2);
		}	
	}

?>

<?php 
function mark_for_100($number){
	switch ($number) {
			case $number<40:
				$point=0.0;
				break;
			case $number>=40 && $number<45:
				$point=2.0;
				break;
			case $number>=45 && $number<50:
				$point=2.25;
				break;		
			case $number>=50 && $number<55:
				$point=2.50;
				break;
			case $number>=55 && $number<60:
				$point=2.75;
				break;	
			case $number>=60 && $number<65:
				$point=3.0;
				break;		
			case $number>=65 && $number<70:
				$point=3.25;
				break;	
			case $number>=70 && $number<75:
				$point=3.50;
				break;	
			case $number>=75 && $number<80:
				$point=3.75;
				break;	
			case $number>=80 && $number<=100:
				$point=4.0;
				break;					
			default:
				
				break;
			}
			return($point);
}

function mark_for_75($number){
	$number=($number*100)/75;
	switch ($number) {
			case $number<40:
				$point=0.0;
				break;
			case $number>=40 && $number<45:
				$point=2.0;
				break;
			case $number>=45 && $number<50:
				$point=2.25;
				break;		
			case $number>=50 && $number<55:
				$point=2.50;
				break;
			case $number>=55 && $number<60:
				$point=2.75;
				break;	
			case $number>=60 && $number<65:
				$point=3.0;
				break;		
			case $number>=65 && $number<70:
				$point=3.25;
				break;	
			case $number>=70 && $number<75:
				$point=3.50;
				break;	
			case $number>=75 && $number<80:
				$point=3.75;
				break;	
			case $number>=80 && $number<=100:
				$point=4.0;
				break;					
			default:
				
				break;
			}
			return($point);
}

function mark_for_50($number){
	$number=($number*100)/50;
	switch ($number) {
			case $number<40:
				$point=0.0;
				break;
			case $number>=40 && $number<45:
				$point=2.0;
				break;
			case $number>=45 && $number<50:
				$point=2.25;
				break;		
			case $number>=50 && $number<55:
				$point=2.50;
				break;
			case $number>=55 && $number<60:
				$point=2.75;
				break;	
			case $number>=60 && $number<65:
				$point=3.0;
				break;		
			case $number>=65 && $number<70:
				$point=3.25;
				break;	
			case $number>=70 && $number<75:
				$point=3.50;
				break;	
			case $number>=75 && $number<80:
				$point=3.75;
				break;	
			case $number>=80 && $number<=100:
				$point=4.0;
				break;					
			default:
				
				break;
			}
			return($point);
}
	


 ?>