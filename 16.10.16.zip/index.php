<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Click to this Link</title>
</head>
<body>
	<a href="year.php">Please CLICK on this link</a>
</body>
</html>